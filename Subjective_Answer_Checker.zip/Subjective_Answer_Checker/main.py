import tkinter as tk
from tkinter import messagebox, StringVar, OptionMenu, Label, Text
import openpyxl
from fuzzywuzzy import fuzz
import json

# Global variables
ans = 0
text = ''
kt = 0
cm = 0
gm = 0
fr = 0
g = 0
file = ""
fileQ = ""
Qtext = ""
frf = 1
ktf = 0
cmf = 0
gmf = 0

def openmyfile(x):
    global fileQ, Qtext, frf, ktf, cmf, gmf
    fileQ = x
    loc = f"Questions/{fileQ}.xlsx"
    
    wb = openpyxl.load_workbook(loc)
    sheet = wb.active
    
    Qtext = sheet['A4'].value
    frf = sheet['B2'].value
    ktf = sheet['C2'].value
    cmf = sheet['D2'].value
    gmf = sheet['E2'].value
    
    ans_key(sheet)

strans = ""
ansl = []
keyword = []
com = ["and", "that", "the", "for", "it", "it's", "was", "his", "who", "work", "used", "way", "also", "by", "can", "which", "as", "known", "then", "if", "between", "through", "another", "", "or", "my", "in", "from", "a", "any", "on", "combination", "to", "into", "is", "of", "It", "A", "each", "both"]

def load_words():
    with open('words_alpha.json') as word_file:
        valid_words = set(word_file.read().split())
    return valid_words



def ans_key(s):
    global strans, ansl, keyword
    strans = ""
    ansl.clear()
    keyword.clear()
    
    for i in range(6, s.max_row + 1):
        t = s.cell(row=i, column=1).value
        if t:
            ansl.append(t)
            strans += f"\n\n{i - 5}) {t}"
    
    for a in ansl:
        ass = a.lower().split()
        for sas in ass:
            if sas not in com and sas not in keyword:
                if any(sas in check.lower().split() for check in ansl if check != a):
                    keyword.append(sas)

class Test(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Question Paper")
        self.geometry("610x377+361+223")

        Label(self, text=Qtext).grid(row=0, column=0, padx=13, pady=21, sticky=tk.W)

        self.entryA = Text(self, height=14, width=46, padx=5, pady=5, wrap=tk.WORD, background='white')
        self.entryA.grid(row=0, column=1, padx=13, pady=21, sticky=tk.E)

        tk.Button(self, text='Submit', command=self.click_ok).grid(row=1, column=1, padx=13, pady=21)

    def click_ok(self):
        global text
        text = self.entryA.get("1.0", tk.END).strip()
        if not text:
            messagebox.showinfo("Blank Input Error", "Please enter a Statement")
        elif len(text.split()) < 5:
            messagebox.showinfo("Too Short Input Error", "Please enter a proper Statement")
        else:
            Report(self)
            self.withdraw()

class App(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.pack()
        self.master.resizable(False, False)
        self.master.tk_setPalette(background='#ececec')
        self.master.geometry("500x190+500+323")
        self.master.title("Automatic Answer Checker")

        tkt = StringVar(self)
        choices = ['E-Commerce', 'NLP', 'Cryptography', 'Cyber-Security', 'Philosophy']
        tkt.set('E-Commerce')
        openmyfile('E-Commerce')

        Label(self, text="Subject: ").grid(row=2, column=0, padx=5, pady=10, sticky=tk.W)
        OptionMenu(self, tkt, *choices).grid(row=2, column=1)

        tkt.trace('w', lambda *args: openmyfile(tkt.get()))

        Label(self, text="Username: ").grid(row=0, column=0, padx=5, pady=10, sticky=tk.W)
        self.entryA = tk.Entry(self, width=26, background='white')
        self.entryA.grid(row=0, column=1, padx=5, pady=10, sticky=tk.W)
        self.entryA.focus_set()

        Label(self, text="Password: ").grid(row=1, column=0, padx=5, pady=10, sticky=tk.W)
        self.entryB = tk.Entry(self, width=26, background='white', show="*")
        self.entryB.grid(row=1, column=1, padx=5, pady=15, sticky=tk.W)

        tk.Button(self, text='Submit', command=self.click_ok).grid(row=3, column=1, padx=13, pady=21, sticky=tk.S)

    def click_ok(self):
        user = self.entryA.get()
        password = self.entryB.get()
        
        wb = openpyxl.load_workbook("login.xlsx")
        sh = wb.active
        
        cuser = [cell.value for cell in sh['A'] if cell.value]
        cpass = [cell.value for cell in sh['B'] if cell.value]
        
        if user in cuser and password in cpass:
            Test(self)
            self.master.withdraw()
        else:
            messagebox.showinfo("Login error", "Please enter the correct credentials")

class Report(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry("350x180+500+300")
        self.title("Evaluation Report")

        global ans, text, kt, cm, gm, fr, g

        ans = 0
        g = 0
        text = text.strip()
        english_words = load_words()

        if text:
            words = text.lower().split()
            g = sum(1 for t in words if t.rstrip('.') in english_words)

            if g > 7:
                for ev in ansl:
                    ans += fuzz.token_set_ratio(ev, text) + fuzz.ratio(ev, text)

        gm = g / len(words) if words else 0
        fr = ans / len(ansl) if ansl else 0

        kt = sum(0.1 if keyword.index(t) == 0 else 0.08 if keyword.index(t) == 1 else 0.05
                 for t in set(words) if t in keyword)
        kt = min(kt, 1)

        check = [i for i in range(len(words) - 1) if words[i] in keyword and words[i + 1] in keyword
                 and keyword.index(words[i]) < keyword.index(words[i + 1])]
        cm = len(check) / len(words) if words else 0

        r = fr / (frf * 100) + ktf * kt + cmf * cm + gmf * gm
        r = min(max(int(r * 20) / 2, 0), 10)

        Label(self, text=f"Your Marks is = {r}").grid(row=2, column=2, padx=10, pady=15, sticky=tk.N)
        tk.Button(self, text="Detailed Report", width=15, command=self.det_report).grid(row=3, column=3, padx=10, pady=15, sticky=tk.N)
        tk.Button(self, text="Close", width=15, command=self.destroy).grid(row=4, column=3, padx=10, pady=15, sticky=tk.N)

    def det_report(self):
        Det_Report(self)

class Det_Report(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry("700x650+361+100")
        self.title("Evaluation Full Report")

        messages = [
            f"Your Total Marks is = {ans}",
            f"The Similarity factor of the sentence is: {fr/100:.2%}",
            f"The Grammar accuracy of the sentence is: {gm:.2%}",
            f"The Total Keywords found in the sentence is: {kt:.2%}",
            f"The Keyword order accuracy of the sentence is: {cm:.2%}"
        ]

        for i, msg in enumerate(messages, start=1):
            tk.Message(self, text=msg, font='Arial 10 underline', justify='left', aspect=1500).grid(row=i, column=2, padx=2, pady=2, sticky=tk.W)

        key = ", ".join(keyword)
        tk.Message(self, text=f"Some of the Sample Answers are: {strans}", font='System 14', justify='left', aspect=200).grid(row=6, column=2, padx=2, pady=2, sticky=tk.W)
        tk.Message(self, text=f"The Keywords Extracted are:\n{key}", font='System 12', justify='left', aspect=900).grid(row=7, column=2, padx=2, pady=2, sticky=tk.W)

        tk.Button(self, text="Close", width=15, command=self.destroy).grid(row=8, column=2, padx=100, pady=15, sticky=tk.S)

if __name__ == '__main__':
    root = tk.Tk()
    app = App(root)
    app.mainloop()
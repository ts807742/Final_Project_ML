# Subjective Answer Checker

This was my 4th Year project where I have used Python to develop a GUI software to create a login screen and a subjective answering screen where the student can login and asnwer the question in a subjective manner and then can be instantly graded based on his asnwer like a real Teacher would grade the student. 

After the Student clicks on the submit button he will be able to see his marks and then can also choose to see a detailed report of his marksheet and what were the correct answers and keywords which were important for a particular question so that they can asnwer better next time.

You would need a machine with python3 installed if you want to execute the python file or you can use pyinstaller to build an exe file which is machine independant and only requires the corresponding CSV files to execute properly.